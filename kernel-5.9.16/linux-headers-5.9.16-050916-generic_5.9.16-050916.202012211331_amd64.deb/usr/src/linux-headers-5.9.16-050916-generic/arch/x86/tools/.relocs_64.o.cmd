cmd_arch/x86/tools/relocs_64.o := gcc -Wp,-MMD,arch/x86/tools/.relocs_64.o.d -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89     -I/home/kernel/COD/linux/tools/include  -I ./arch/x86/tools -c -o arch/x86/tools/relocs_64.o /home/kernel/COD/linux/arch/x86/tools/relocs_64.c

source_arch/x86/tools/relocs_64.o := /home/kernel/COD/linux/arch/x86/tools/relocs_64.c

deps_arch/x86/tools/relocs_64.o := \
  /home/kernel/COD/linux/arch/x86/tools/relocs.h \
  /home/kernel/COD/linux/tools/include/tools/le_byteshift.h \
  /home/kernel/COD/linux/arch/x86/tools/relocs.c \

arch/x86/tools/relocs_64.o: $(deps_arch/x86/tools/relocs_64.o)

$(deps_arch/x86/tools/relocs_64.o):
