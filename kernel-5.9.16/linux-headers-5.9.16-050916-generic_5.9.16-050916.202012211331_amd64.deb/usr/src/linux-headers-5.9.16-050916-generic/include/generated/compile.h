/* This file is auto generated, version 202012211331 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202012211331 SMP Mon Dec 21 14:11:13 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "sita"
#define LINUX_COMPILER "gcc (Ubuntu 10.2.0-13ubuntu1) 10.2.0, GNU ld (GNU Binutils for Ubuntu) 2.35.1"
