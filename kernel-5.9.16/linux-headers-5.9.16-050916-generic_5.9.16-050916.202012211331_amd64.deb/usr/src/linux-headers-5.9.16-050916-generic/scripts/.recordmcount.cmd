cmd_scripts/recordmcount := gcc -Wp,-MMD,scripts/.recordmcount.d -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89       -I ./scripts   -o scripts/recordmcount /home/kernel/COD/linux/scripts/recordmcount.c   

source_scripts/recordmcount := /home/kernel/COD/linux/scripts/recordmcount.c

deps_scripts/recordmcount := \
  /home/kernel/COD/linux/scripts/recordmcount.h \

scripts/recordmcount: $(deps_scripts/recordmcount)

$(deps_scripts/recordmcount):
