cmd_scripts/sign-file := gcc -Wp,-MMD,scripts/.sign-file.d -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89       -I ./scripts   -o scripts/sign-file /home/kernel/COD/linux/scripts/sign-file.c   -lcrypto

source_scripts/sign-file := /home/kernel/COD/linux/scripts/sign-file.c

deps_scripts/sign-file := \

scripts/sign-file: $(deps_scripts/sign-file)

$(deps_scripts/sign-file):
