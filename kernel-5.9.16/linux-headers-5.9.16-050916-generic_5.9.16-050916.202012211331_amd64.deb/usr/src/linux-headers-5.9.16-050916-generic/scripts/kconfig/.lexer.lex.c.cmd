cmd_scripts/kconfig/lexer.lex.c := flex -oscripts/kconfig/lexer.lex.c -L /home/kernel/COD/linux/scripts/kconfig/lexer.l
