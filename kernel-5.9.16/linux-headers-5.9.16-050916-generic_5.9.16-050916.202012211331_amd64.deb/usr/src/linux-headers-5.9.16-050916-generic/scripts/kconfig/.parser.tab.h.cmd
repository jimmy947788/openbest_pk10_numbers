cmd_scripts/kconfig/parser.tab.h := bison -o scripts/kconfig/parser.tab.c --defines=scripts/kconfig/parser.tab.h -t -l /home/kernel/COD/linux/scripts/kconfig/parser.y
