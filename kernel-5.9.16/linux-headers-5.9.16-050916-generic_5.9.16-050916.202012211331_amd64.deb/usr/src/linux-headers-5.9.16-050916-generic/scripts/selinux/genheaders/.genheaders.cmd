cmd_scripts/selinux/genheaders/genheaders := gcc -Wp,-MMD,scripts/selinux/genheaders/.genheaders.d -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89     -I/home/kernel/COD/linux/include/uapi -I/home/kernel/COD/linux/include -I/home/kernel/COD/linux/security/selinux/include  -I ./scripts/selinux/genheaders   -o scripts/selinux/genheaders/genheaders /home/kernel/COD/linux/scripts/selinux/genheaders/genheaders.c   

source_scripts/selinux/genheaders/genheaders := /home/kernel/COD/linux/scripts/selinux/genheaders/genheaders.c

deps_scripts/selinux/genheaders/genheaders := \
  /home/kernel/COD/linux/security/selinux/include/classmap.h \
  /home/kernel/COD/linux/include/uapi/linux/capability.h \
  /home/kernel/COD/linux/include/uapi/linux/types.h \
  /home/kernel/COD/linux/include/uapi/linux/posix_types.h \
  /home/kernel/COD/linux/include/uapi/linux/stddef.h \
  /home/kernel/COD/linux/include/linux/compiler_types.h \
    $(wildcard include/config/have/arch/compiler/h.h) \
    $(wildcard include/config/enable/must/check.h) \
    $(wildcard include/config/cc/has/asm/inline.h) \
  /home/kernel/COD/linux/include/uapi/linux/socket.h \
  /home/kernel/COD/linux/security/selinux/include/initial_sid_to_string.h \

scripts/selinux/genheaders/genheaders: $(deps_scripts/selinux/genheaders/genheaders)

$(deps_scripts/selinux/genheaders/genheaders):
