cmd_/home/kernel/COD/linux/debian/linux-headers-5.9.16-050916-generic/usr/src/linux-headers-5.9.16-050916-generic/tools/objtool/subcmd-config.o := gcc -Wp,-MD,/home/kernel/COD/linux/debian/linux-headers-5.9.16-050916-generic/usr/src/linux-headers-5.9.16-050916-generic/tools/objtool/.subcmd-config.o.d -Wp,-MT,/home/kernel/COD/linux/debian/linux-headers-5.9.16-050916-generic/usr/src/linux-headers-5.9.16-050916-generic/tools/objtool/subcmd-config.o -ggdb3 -Wall -Wextra -std=gnu99 -fPIC -O6 -Werror -D_LARGEFILE64_SOURCE -D_FILE_OFFSET_BITS=64 -D_GNU_SOURCE -I/home/kernel/COD/linux/tools/include/ -Wbad-function-cast -Wdeclaration-after-statement -Wformat-security -Wformat-y2k -Winit-self -Wmissing-declarations -Wmissing-prototypes -Wnested-externs -Wno-system-headers -Wold-style-definition -Wpacked -Wredundant-decls -Wstrict-prototypes -Wswitch-default -Wswitch-enum -Wundef -Wwrite-strings -Wformat -Wstrict-aliasing=3 -Wshadow -D"BUILD_STR(s)=$(pound)s" -c -o /home/kernel/COD/linux/debian/linux-headers-5.9.16-050916-generic/usr/src/linux-headers-5.9.16-050916-generic/tools/objtool/subcmd-config.o subcmd-config.c

source_/home/kernel/COD/linux/debian/linux-headers-5.9.16-050916-generic/usr/src/linux-headers-5.9.16-050916-generic/tools/objtool/subcmd-config.o := subcmd-config.c

deps_/home/kernel/COD/linux/debian/linux-headers-5.9.16-050916-generic/usr/src/linux-headers-5.9.16-050916-generic/tools/objtool/subcmd-config.o := \
  /usr/include/stdc-predef.h \
  subcmd-config.h \

/home/kernel/COD/linux/debian/linux-headers-5.9.16-050916-generic/usr/src/linux-headers-5.9.16-050916-generic/tools/objtool/subcmd-config.o: $(deps_/home/kernel/COD/linux/debian/linux-headers-5.9.16-050916-generic/usr/src/linux-headers-5.9.16-050916-generic/tools/objtool/subcmd-config.o)

$(deps_/home/kernel/COD/linux/debian/linux-headers-5.9.16-050916-generic/usr/src/linux-headers-5.9.16-050916-generic/tools/objtool/subcmd-config.o):
